class Feedback < ActiveRecord::Base
  belongs_to :user
end
