#require_dependency "opinion_status.rb" # memcached vaatii tätä - similarsissa tallennetaan os:ia

class OpinionStatusController < ApplicationController
#  before_filter  :preload_models
# 
#  def preload_models()
#    OpinionStatus
#  end

  def modify_opinion
    create_user if session[:user].nil? and (params[:status]=='1' or params[:status]=='2') and request.method == :post
    
    if session[:user]
      params[:status] = 3 if params[:hide]
      #os = OpinionStatus.find_or_create_by_user_id_and_opinion_id(:user_id => session[:user].id, :opinion_id => params[:opinion_id])
      os = OpinionStatus.find_by_user_id_and_opinion_id(session[:user].id, params[:opinion_id])
      if os.nil?
        os = OpinionStatus.create(:user_id => session[:user].id, :opinion_id => params[:opinion_id], :status => params[:status], :anonymous => session[:anonymous])
#        session[:oses] << os
      else
        if os.status == params[:status].to_i and session[:anonymous] == os.anonymous
         # sama tilaa painettu toiseen kertaan; deletoidaan.
#          session[:oses].delete(os)
          os.destroy
        else
          os.status = params[:status]
          os.anonymous = session[:anonymous] ? true : false
          os.save
#          ses_os = session[:oses].select { |sos| sos == os }[0]
#          ses_os = os
        end
      end
      session[:oses] = session[:user].opinion_statuses
      os.opinion.update_op_stat_counters
      delete_cache(params[:opinion_id], session[:user].id)
    end
    
    
    # SEKALAISTA
#    oses = session[:oses].size
#    if oses==5 or oses==15 or oses==40 or oses==100
#      session[:user].similar_users(true) # <- tämä sen takia että luo uudestaan similarity prosentin kaikkien käyttäjien kanssa
#    end
    
    # SIVUN RENDERÖINTI:
    if !defined? os # tää voi tapahtuu vaan jos ei oo käyttäjän luonto on epäonnistunut
      opinion = nil
    else
      opinion = os.opinion
    end
    
#    if params[:big]
#      render :partial => '/opinion/your_opinion', :locals => {:opinion => opinion}
#    elsif
    if params[:hide] and !session[:opinions].nil?
      opinion = Opinion.find(params[:opinion_id])
      session[:opinions].delete(opinion)
      session[:opinions_removed] += 1
    elsif params[:no_render]
      render :text => ""
    else
      render :partial => 'opinion/opinion', :locals => {:opinion => opinion, :from_modify => true}
    end
  end

  def change_anonymity
    if params[:type] == 'OpinionStatus'
      item = OpinionStatus.find(params[:id])
    elsif params[:type] == 'Opinion'
      item = Opinion.find(params[:id])
    else # params[:type] == 'Comment'
      item = Comment.find(params[:id])
    end
    
    if (params[:type] == 'Opinion' and item.creator == session[:user]) or item.user == session[:user]
      item.update_attribute(:anonymous, !item.anonymous)
    end
  end
  
  private
  
  def delete_cache(op_id, user_id)
    
    Rails.cache.delete("site_stats")
    Rails.cache.delete("latest_opinions[#{op_id}]")
    Rails.cache.delete("opinion_salience[#{op_id}]")
    Rails.cache.delete("opinion_details[#{op_id}]")
      
    counter = Rails.cache.read("op_cache_counter[#{op_id}]")
    counter = counter.nil? ? 1 : counter + 1
    Rails.cache.write("op_cache_counter[#{op_id}]", counter)
    
    if counter%10 == 0
      Rails.cache.delete("similar_opinions[#{op_id}]")
      Rails.cache.delete("pos_correlations[#{op_id}]")
      Rails.cache.delete("neg_correlations[#{op_id}]")
      
      # peer percentages:
      User.all.each do |u|
        Rails.cache.delete("peer_percentages[#{u.id}-#{op_id}]")
      end
    end
    
    session[:counter] = session[:counter].nil? ? 1 : session[:counter]+1
    
    if session[:counter]%10 == 0
      #User similarities
      User.all.each do |u|
        ids = user_id < u.id ? "#{user_id}-#{u.id}" : "#{u.id}-#{user_id}"
        Rails.cache.delete("users_similarity[#{ids}]")
      end
      # similar users:
      Rails.cache.delete("similar_users[#{user_id}]") # muiden suhde tähän käyttäjään ei päivity, mut eipä tuolla niin väliks
    end
  end
end