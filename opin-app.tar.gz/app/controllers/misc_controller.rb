class MiscController < ApplicationController
  
  def debug  
  end
  
  def main_page
    
    checks_before_render_main_page
    
    #@opinions = Opinion.all(:order => 'id DESC')
  end
  
  def next_opinions
    session[:index] += ($op_per_page - session[:opinions_removed])
    redirect_to :action => 'main_page'
#    render :template => '/misc/main_page'
  end
  
  def previous_opinions
    session[:index] -= $op_per_page
    redirect_to :action => 'main_page'
#    render :template => '/misc/main_page'
  end
  
  def reset_opinions(update_show_answered=true)
#    session[:opinions_updated] = Time.now
#    render :text => session[:hide_answered].class and return
    session[:show_answered] = params[:show_answered] if update_show_answered
    if session[:show].nil? or session[:show][:all]
      redirect_to :action => 'opinions_all'
    elsif session[:show][:tag]
      redirect_to :action => 'opinions_by_tag'
    else #session[:show][:new]
      redirect_to :action => 'opinions_new'
    end
  end
  
  def opinions_by_tag
#    render :text => Tag.tag_hash.inspect and return
    session[:index] = 0
    session[:opinions] = []
    session[:show] = { :tag => params[:tag] } unless params[:tag].nil?
#    render :text => params[:tag] + Tag.tag_hash[params[:tag]].inspect
    unless Tag.tag_hash[session[:show][:tag]].nil? # tapahtuu lähinnä sillon jos uutta tagia ei oo vielä cachessa
      Tag.tag_hash[session[:show][:tag]].each do |op_id|
        op = Opinion.find_by_id(op_id)
        session[:opinions] << op unless op.nil? # jos tuhottu, mutta edelleen tag-cachessa
      end
    end
    remove_hidden if session[:user]
    session[:opinions].sort! { |a,b| b.salience <=> a.salience }
    if session[:opinions].size > 0
      session[:opinions_text] = "Mielipiteet tagilla: &nbsp;<h3 style='display:inline'>#{session[:show][:tag].gsub(/_/, ' ').capitalize}</h3>"
    else
      session[:opinions_text] = "Ei yhtään mielipidettä tagilla: &nbsp;<h3 style='display:inline'>#{session[:show][:tag].gsub(/_/, ' ').capitalize}</h3>. Mikäli tagi on listätty äskettäin voi sen päivittyminen tälle sivulle kestää hetken."
    end
    session[:opinions_updated] = Time.now
    checks_before_render_main_page
    render :action => 'main_page'
  end
  
  def opinions_all
    session[:index] = 0
    session[:show] = { :all => true }
    session[:opinions] = Opinion.all
    session[:opinions_text] = "&nbsp;<h3 style='display:inline'>Suositut</h3>"
    remove_hidden if session[:user]
    #session[:opinions_text] = "<div style='font-size:0.8em'>#{removed} vastattua mielipidettä piilotettu</div>" if removed and removed > 0
    session[:opinions].sort! { |a,b| b.salience <=> a.salience }

    session[:opinions_updated] = Time.now
    redirect_to :action => 'main_page'
    
    # JOKU PÄIVÄ TÄN VOIS tehä niinkin et ois status_opinioneja oninionin sijaan; ois huomattavasti tehokkaampi, koska nyt status_opinonit pitää taas hakee erikseen viewissä
  end
  
  def opinions_new
    session[:index] = 0
    session[:show] = { :new => true }
    session[:opinions] = Opinion.all
    remove_hidden if session[:user]
    session[:opinions_text] = "&nbsp;<h3 style='display:inline'>Uudet</h3>"
    session[:opinions].sort! { |a,b| b.created_at <=> a.created_at }
    
    session[:opinions_updated] = Time.now
    redirect_to :action => 'main_page'
  end
  
  def show_current_user
    redirect_to :controller => 'user', :action => 'show', :login => session[:user].login
  end
  
  def show_current_user_settings
    redirect_to :controller => 'user', :action => 'settings', :login => session[:user].login
  end
  
  def anonym_mode
    session[:anonymous] = session[:anonymous] ? nil : true
    render :partial => 'misc/anonym_mode'
  end
  
  def search
    if params[:search].blank?
      session[:opinions_text] = "<div style='color:red'>Hakulauseesi oli tyhjä!</div>"
      redirect_to :action => "main_page" and return
    end
    results = Opinion.search params[:search], :case => :sensitive
    if results.size > 0
      session[:opinions] = results
      session[:index] = 0
      session[:opinions_text] = "<div style='color:green'>Tulokset hakulauseella \"<strong>#{params[:search]}</strong>\":</div>"
    else
      session[:opinions_text] = "<div style='color:red'>Haulla \"<strong>#{params[:search]}</strong>\" ei löytynyt tuloksia.</div><div>Ehkä haluaisit tehdä aiheesta uuden mielipiteen?</div>"
      session[:opinions] = []
      flash[:search_to_new_opinion] = params[:search]
    end
    flash[:searchwords] = params[:search]
    redirect_to :action => "main_page"
#    render :text => Opinion.all.inspect #params[:search].inspect
  end
  
  def info
    
  end
  
  def new_feedback
    Feedback.create(:user_id => (session[:user] ? session[:user].id : nil), :text => params[:feedback_text])
    render :text => "<div style='font-weight:bold;color:green;'>Kiitos palautteestasi!</div><div>Mikäli laitoit palautteen mukaan sähköpostiosoitteesi, vastaamme siihen mahdollisimman pian.</div><br/>"
  end
  

  # MAINTENANCE
  
  def testi
    $testi = $testi.nil? ? "testi" : $testi + " testi"
  end
  
  def cache
    html = Rails.cache.inspect
    html << "<br/> active: #{Rails.cache.data.active?}"
    render :text => html # MemCache.inspect
  end
  
  def cache_test
    time = Rails.cache.fetch("cache_test", :expires_in => 10.seconds) do
      Time.now
    end
    render :text => "aika: #{time.strftime('%H:%M:%S')}"
  end
  
  def empty_cache
    Rails.cache.clear
    render :text => "done"
  end
  
  def inspect_sessions
    html = ''
    sessions = CGI::Session::ActiveRecordStore::Session.all
    sessions.each do |s|
      begin
        html << "<li>size: #{s.data.length} &nbsp; #{s.session_id} #{s.id} &nbsp; #{s.inspect}</li>"
      rescue
        html << "epäonnistui"
      end
    end
    render :text => html
  end
  
  def destroy_empty_users
    users = User.all
    users.each do |u|
      next if u.comments.size > 0 or u.opinions.size > 0
      destroy_user = true
      u.opinion_statuses.each do |os|
        if os.status == 1 or os.status == 2
          destroy_user = false
          break
        end
      end
      u.destroy if destroy_user
    end
    redirect_to :action => 'destroy_empty_opinion_statuses'
    #render :text => "done"
  end
  
  def destroy_empty_opinion_statuses
    oses = OpinionStatus.all
    oses.each do |os|
      os.destroy if os.user.nil?
    end
    render :text => "done"
  end
  
  
  
  # NOT MAINTANENCE...
  
  private
  
  def remove_hidden
    removed = 0
    session[:oses].each do |os|
      if os.status == 3 # piilotettu
        unless session[:opinions].delete(os.opinion).nil?
          removed += 1
        end
      elsif session[:show_answered].nil? and (os.status == 1 or os.status == 2)
        unless session[:opinions].delete(os.opinion).nil?
          removed += 1
        end
      end
    end
    session[:op_hidden] = removed # tätä ei tällä hetkellä käytetä, mut vois ehkä myöhemmin näyttää jossain?
  end
  
  def checks_before_render_main_page
    if session[:opinions].nil? or session[:opinions_updated].nil? or (Time.now-session[:opinions_updated]) > 1.hour
      reset_opinions(false)
      return 
    end
    session[:index] = 0 if session[:index].nil? # tämä ei normaalisti ole mahdollista - ainoastaan jos on vanha käyttäjä jolle :indexiä ei ole asetettu
    session[:opinions_removed] = 0
    session[:index] -= $op_per_page if session[:index] > session[:opinions].size
    session[:index] = 0 if session[:index] < 0
    
    # käyttäjätunnus muistutu:
    if (session[:oses] and !session[:user].has_login?) and ((session[:login_reminder].nil? and session[:oses].size > 15) or (session[:login_reminder] and session[:login_reminder] < 2 and session[:oses].size > 70))
      flash[:notice] = "Hei, laitappa itsellesi joku mukava käyttäjätunnus ja salasana <a href='/misc/show_current_user_settings'>Asetukset</a> sivulta. Niiden avulla pääset mm. kirjautumaan palveluun muilta tietokoneilta.<br/><br/> Mikäli et halua kaikkien mielipiteidesi näkyvän julkisesti voit muuttaa ne helposti anonyymeiksi <a href='/misc/show_current_user'>profiilistasi</a>."
      flash[:color] = "yellow"
      flash[:timer] = 100000
      session[:login_reminder] = session[:login_reminder].nil? ? 1 : session[:login_reminder]+1
    end
  end
  
end
