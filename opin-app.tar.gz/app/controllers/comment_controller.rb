class CommentController < ApplicationController

  def create_new
    create_user if session[:user].nil?
    
    unless params[:filter].blank?
      render :text => "kommenttisi jäi spämmi filtteriin" and return
    end
    comment = Comment.new(params[:comment])
    comment.user_id = session[:user].id
    comment.anonymous = session[:anonymous] ? true : false
    if comment.save
      opinion = comment.opinion
      render :partial => "comments", :locals => {:opinion => opinion}
    else
      render :text => "kommetin tallentaminen ei onnistunut, #{comment.inspect}"
    end
  end
  
  def comments
    #@comments = Comment.find_by_opinion_id(:opinion_id => params[:opinion_id], :conditions => {:reply_id => nil}, :order => "reverse")
#    if video = Video.find(params[:video_id])
#      render :partial => "comments", :locals => {:video => video}
#    else
#      render :text => "BUG: video not found!"
#    end
  end

  def new_comment_form
    #render :text => 'plaa'
    comment = Comment.find(params[:reply_to_id])
    render :partial => 'comment/new_comment_form', :locals => {:opinion => comment.opinion, :reply_id => params[:reply_to_id]}
  end
  
end
