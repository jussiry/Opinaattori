module UserHelper
#  def sex_as_string(sex)
#    return "Mies" if sex == 1
#    return "Nainen" if sex == 2
#  end
end
